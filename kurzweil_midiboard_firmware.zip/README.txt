> Hi.  Here is the MidiBoard EPROM file.  Again, ignore the .HS and .LS files
> and use the .H and .L files.  The text file documents the checksums.
> 
> It would be interesting to read the the checksums of the existing chips to see
> if they are correct or not.
> 
> EPROMs common in the 80's did run noticeably warm but they definitely should
> not be hot.  I think the service tech should check the 5V supply voltage at
> the power and ground pins of the EPROMs (pin 14 is ground (-) and pin 28 is
> +). If correct (4.75 - 5.25V), then there is a possibility that some other
> chip on the databus bus is always active and fighting with the EPROMs.  That
> other chip would be warm too.
> 
> Don't forget to check the memory backup battery voltage a few hours after
> power off.  Its the yellow cylinder near the heatsinks.  Needs to be at least
> 2.0V to power the memory but anything less than 2.5V means its well over 90%
> exhausted.  
> 
> Howard Chamberlin, Consultant
> Young Chang R&D Institute / Kurzweil Music Systems
> 

>> Good morning from Germany :)
>> 
>> Thanks you very much for the swift reply ! Yes, the board already had
>> the latest software. I used to have it always connected to power for at
>> least a decade but I recently moved and it was disconnected for about 4
>> weeks. When I tried to turn it on again, it would lock up very early in
>> the boot-up phase (sometimes not even displaying any of the POST codes
>> or switching on just a few seemingly random segments of the display).
>> 

>>> Good evening from South Korea.
>>>
>>> I have attached binary images for the latest version of Midiboard
>>> software -
>>> V3. The images applicable to your MidiBoard have .H and .L in the file
>>> names. The H chip goes into the small socket and the L chip goes into the
>>> overly long socket
>>>
>>> However it sounds like your MidiBoard already has the latest version
>>> (the previous version only used one EPROM). So what is the nature of the
>>> problem?
>>>
>>> If it is failure to start up but the supply voltages are correct
>>> (especially +5V that runs all of the logic), then oftentimes that can be
>>> resolved by unplugging the existing EPROMs, cleaning the pins by lightly
>>> rubbing with a pink wedge-shaped eraser, and plugging back in. otherwise,
>>> refreshing the data is certainly worth trying as EPROMs are only
>>> guaranteed to
>>> retain data for 10 years.
>>>
>>> Howard Chamberlin, Consultant
>>> Young Chang R&D Institute / Kurzweil Music Systems
